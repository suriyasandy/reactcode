import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { credentialSetupSchema, type CredentialSetup } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface CredentialsModalProps {
  open: boolean;
  onSuccess: () => void;
  onClose: () => void;
}

export default function CredentialsModal({ open, onSuccess, onClose }: CredentialsModalProps) {
  const { toast } = useToast();

  const form = useForm<CredentialSetup>({
    resolver: zodResolver(credentialSetupSchema),
    defaultValues: {
      uatUsername: "",
      uatPassword: "",
      uatApiUrl: "https://uat-api.example.com",
      prodUsername: "",
      prodPassword: "",
      prodApiUrl: "https://prod-api.example.com",
      exceptionUsername: "",
      exceptionPassword: "",
      exceptionClientId: "",
      exceptionClientSecret: "",
      exceptionApiUrl: "https://exception-api.example.com",
    },
  });

  const credentialsMutation = useMutation({
    mutationFn: async (data: CredentialSetup) => {
      const response = await apiRequest('POST', '/api/credentials/setup', data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Credentials Saved",
        description: "All credentials have been stored securely",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Setup Failed",
        description: error.message || "Failed to save credentials",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CredentialSetup) => {
    credentialsMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <i className="fas fa-key text-primary"></i>
            Environment Credentials Setup
          </DialogTitle>
          <p className="text-sm text-neutral-500">
            Configure credentials for UAT, PROD, and Exception API access
          </p>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Tabs defaultValue="uat" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="uat">UAT Environment</TabsTrigger>
                <TabsTrigger value="prod">PROD Environment</TabsTrigger>
                <TabsTrigger value="exception">Exception API</TabsTrigger>
              </TabsList>

              {/* UAT Credentials */}
              <TabsContent value="uat">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">UAT Environment</CardTitle>
                    <p className="text-sm text-neutral-500">
                      Credentials for downloading trade data from UAT environment
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="uatUsername"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter UAT username" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="uatPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Enter UAT password" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="uatApiUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://uat-api.example.com" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>

              {/* PROD Credentials */}
              <TabsContent value="prod">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">PROD Environment</CardTitle>
                    <p className="text-sm text-neutral-500">
                      Credentials for downloading trade data from PROD environment
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="prodUsername"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter PROD username" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="prodPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Enter PROD password" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="prodApiUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://prod-api.example.com" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Exception API Credentials */}
              <TabsContent value="exception">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Exception API</CardTitle>
                    <p className="text-sm text-neutral-500">
                      Credentials for downloading exception data (requires OAuth credentials)
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="exceptionUsername"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter username" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="exceptionPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Enter password" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="exceptionClientId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Client ID</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter client ID" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="exceptionClientSecret"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Client Secret</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Enter client secret" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="exceptionApiUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://exception-api.example.com" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <div className="flex justify-between items-center pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={credentialsMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={credentialsMutation.isPending}
                className="bg-success hover:bg-green-700"
              >
                {credentialsMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save mr-2"></i>
                    Save Credentials
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}