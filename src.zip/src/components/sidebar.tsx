import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { api } from "@/lib/api";

const dataSourceSchema = z.object({
  productType: z.string().min(1, "Product type is required"),
  legalEntity: z.string().min(1, "Legal entity is required"),
  sourceSystem: z.string().min(1, "Source system is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
});

type DataSourceFormData = z.infer<typeof dataSourceSchema>;

interface SidebarProps {
  onDownloadData: (config: DataSourceFormData) => void;
}

export default function Sidebar({ onDownloadData }: SidebarProps) {
  const [thresholdView, setThresholdView] = useState<'groupwise' | 'currencywise'>('groupwise');
  const [uploadingFile, setUploadingFile] = useState(false);
  const { toast } = useToast();

  const form = useForm<DataSourceFormData>({
    resolver: zodResolver(dataSourceSchema),
    defaultValues: {
      productType: "",
      legalEntity: "",
      sourceSystem: "",
      startDate: "",
      endDate: "",
    },
  });

  const uploadMutation = useMutation({
    mutationFn: api.uploadThresholds,
    onSuccess: (data) => {
      toast({
        title: "Upload Successful",
        description: `${data.count} thresholds uploaded successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/thresholds'] });
      setUploadingFile(false);
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload threshold file",
        variant: "destructive",
      });
      setUploadingFile(false);
    },
  });

  const runImpactMutation = useMutation({
    mutationFn: api.runImpactAnalysis,
    onSuccess: () => {
      toast({
        title: "Impact Analysis Complete",
        description: "Threshold impact analysis has been completed",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/analysis/results'] });
    },
    onError: (error: any) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "Impact analysis failed",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadingFile(true);
      uploadMutation.mutate(file);
    }
  };

  const onSubmit = (data: DataSourceFormData) => {
    onDownloadData(data);
  };

  return (
    <div className="w-80 bg-white shadow-lg flex flex-col">
      <div className="p-6 border-b">
        <h1 className="text-xl font-bold text-neutral-800">GFX Dashboard</h1>
        <p className="text-sm text-neutral-500 mt-1">Threshold Deviation Analysis</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6">
        {/* Data Source Controls */}
        <div className="mb-8">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Data Source</h3>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="productType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Product Type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="FX">FX</SelectItem>
                        <SelectItem value="MM">MM</SelectItem>
                        <SelectItem value="FI">FI</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="legalEntity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Legal Entity</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Legal Entity" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="JPMCB">JPMCB</SelectItem>
                        <SelectItem value="JPML">JPML</SelectItem>
                        <SelectItem value="ALL">ALL</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="sourceSystem"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Source System</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Source System" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="MUREX">MUREX</SelectItem>
                        <SelectItem value="KONDOR">KONDOR</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-3">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </form>
          </Form>
        </div>
        
        {/* Threshold Configuration */}
        <div className="mb-8">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Threshold Configuration</h3>
          
          {/* File Upload Zone */}
          <Card className="border-2 border-dashed border-neutral-300 p-6 text-center hover:border-primary transition-colors cursor-pointer">
            <div className="space-y-2">
              <i className="fas fa-cloud-upload-alt text-2xl text-neutral-400"></i>
              <p className="text-sm font-medium text-neutral-600">
                {uploadingFile ? "Uploading..." : "Upload Threshold File"}
              </p>
              <p className="text-xs text-neutral-500">CSV with LegalEntity, CCY, Original_Group, etc.</p>
            </div>
            <input 
              type="file" 
              className="hidden" 
              accept=".csv,.xlsx" 
              onChange={handleFileUpload}
              id="threshold-upload"
            />
            <Label htmlFor="threshold-upload" className="cursor-pointer" />
          </Card>
          
          {/* Threshold View Toggle */}
          <div className="mt-4">
            <Label className="block text-sm font-medium text-neutral-600 mb-3">Threshold View</Label>
            <div className="flex space-x-1 bg-neutral-100 p-1 rounded-lg">
              <Button
                variant={thresholdView === 'groupwise' ? 'default' : 'ghost'}
                size="sm"
                className="flex-1"
                onClick={() => setThresholdView('groupwise')}
              >
                Group-wise
              </Button>
              <Button
                variant={thresholdView === 'currencywise' ? 'default' : 'ghost'}
                size="sm"
                className="flex-1"
                onClick={() => setThresholdView('currencywise')}
              >
                Currency-wise
              </Button>
            </div>
          </div>
        </div>
        
        {/* Actions */}
        <div className="space-y-3">
          <Button 
            className="w-full"
            onClick={form.handleSubmit(onSubmit)}
          >
            <i className="fas fa-download mr-2"></i>
            Download Trade Data
          </Button>
          <Button 
            className="w-full bg-success hover:bg-green-700"
            onClick={() => runImpactMutation.mutate()}
            disabled={runImpactMutation.isPending}
          >
            <i className="fas fa-play mr-2"></i>
            {runImpactMutation.isPending ? "Running..." : "Run Threshold Impact"}
          </Button>
        </div>
      </div>
      
      {/* Status Footer */}
      <div className="p-4 border-t bg-neutral-50">
        <div className="flex items-center text-sm">
          <div className="w-2 h-2 bg-success rounded-full mr-2"></div>
          <span className="text-neutral-600">Connected to UAT & PROD</span>
        </div>
      </div>
    </div>
  );
}
