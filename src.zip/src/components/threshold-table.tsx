import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { queryClient } from "@/lib/queryClient";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export default function ThresholdTable() {
  const [editingRows, setEditingRows] = useState<Set<number>>(new Set());
  const [editValues, setEditValues] = useState<Record<number, any>>({});
  const { toast } = useToast();

  const { data: thresholds, isLoading } = useQuery({
    queryKey: ['/api/thresholds'],
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: any }) => 
      api.updateThreshold(id, updates),
    onSuccess: () => {
      toast({
        title: "Threshold Updated",
        description: "Threshold has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/thresholds'] });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update threshold",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (threshold: any) => {
    setEditingRows(prev => new Set([...prev, threshold.id]));
    setEditValues(prev => ({
      ...prev,
      [threshold.id]: {
        adjustedGroup: threshold.adjustedGroup,
        adjustedThreshold: threshold.adjustedThreshold,
      }
    }));
  };

  const handleSave = (id: number) => {
    const values = editValues[id];
    if (values) {
      updateMutation.mutate({ id, updates: values });
      setEditingRows(prev => {
        const newSet = new Set(prev);
        newSet.delete(id);
        return newSet;
      });
    }
  };

  const handleCancel = (id: number) => {
    setEditingRows(prev => {
      const newSet = new Set(prev);
      newSet.delete(id);
      return newSet;
    });
    setEditValues(prev => {
      const newValues = { ...prev };
      delete newValues[id];
      return newValues;
    });
  };

  const handleInputChange = (id: number, field: string, value: any) => {
    setEditValues(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: field === 'adjustedThreshold' ? parseFloat(value) || 0 : value,
      }
    }));
  };

  const resetAllThresholds = () => {
    // Reset all adjusted values to proposed values
    if (thresholds) {
      thresholds.forEach((threshold: any) => {
        updateMutation.mutate({
          id: threshold.id,
          updates: {
            adjustedGroup: threshold.proposedGroup,
            adjustedThreshold: threshold.proposedThreshold,
          }
        });
      });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <i className="fas fa-spinner fa-spin mr-2"></i>
            Loading thresholds...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!thresholds || thresholds.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <i className="fas fa-table text-4xl text-neutral-300 mb-4"></i>
            <h3 className="text-lg font-medium text-neutral-700 mb-2">No Thresholds Available</h3>
            <p className="text-neutral-500">Upload a threshold file to get started.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Threshold Configuration</CardTitle>
          <Badge variant="secondary">Group-wise</Badge>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Legal Entity</TableHead>
                <TableHead>Currency</TableHead>
                <TableHead>Original Group</TableHead>
                <TableHead>Original Threshold</TableHead>
                <TableHead>Proposed Group</TableHead>
                <TableHead>Proposed Threshold</TableHead>
                <TableHead>Adjusted Group</TableHead>
                <TableHead>Adjusted Threshold</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {thresholds.map((threshold: any) => (
                <TableRow key={threshold.id} className="hover:bg-neutral-50">
                  <TableCell className="font-medium">{threshold.legalEntity}</TableCell>
                  <TableCell>{threshold.currency}</TableCell>
                  <TableCell>{threshold.originalGroup}</TableCell>
                  <TableCell>{threshold.originalThreshold}</TableCell>
                  <TableCell>{threshold.proposedGroup}</TableCell>
                  <TableCell>{threshold.proposedThreshold}</TableCell>
                  <TableCell>
                    {editingRows.has(threshold.id) ? (
                      <Input
                        type="text"
                        value={editValues[threshold.id]?.adjustedGroup || ''}
                        onChange={(e) => handleInputChange(threshold.id, 'adjustedGroup', e.target.value)}
                        className="w-16"
                      />
                    ) : (
                      threshold.adjustedGroup
                    )}
                  </TableCell>
                  <TableCell>
                    {editingRows.has(threshold.id) ? (
                      <Input
                        type="number"
                        step="0.1"
                        value={editValues[threshold.id]?.adjustedThreshold || ''}
                        onChange={(e) => handleInputChange(threshold.id, 'adjustedThreshold', e.target.value)}
                        className="w-20"
                      />
                    ) : (
                      threshold.adjustedThreshold
                    )}
                  </TableCell>
                  <TableCell>
                    {editingRows.has(threshold.id) ? (
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleSave(threshold.id)}
                          disabled={updateMutation.isPending}
                        >
                          <i className="fas fa-check"></i>
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleCancel(threshold.id)}
                        >
                          <i className="fas fa-times"></i>
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(threshold)}
                      >
                        <i className="fas fa-edit"></i>
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        <div className="flex justify-between items-center mt-6 pt-4 border-t">
          <span className="text-sm text-neutral-500">
            {thresholds.length} threshold configurations
          </span>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={resetAllThresholds}>
              <i className="fas fa-undo mr-2"></i>
              Reset All
            </Button>
            <Button className="bg-success hover:bg-green-700">
              <i className="fas fa-save mr-2"></i>
              Save Changes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
