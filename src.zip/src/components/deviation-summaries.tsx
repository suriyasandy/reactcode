import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export default function DeviationSummaries() {
  const [selectedBucket, setSelectedBucket] = useState<string | null>(null);
  const [selectedBounds, setSelectedBounds] = useState<{ lower: number; upper?: number } | null>(null);
  const { toast } = useToast();

  const { data: buckets, isLoading: bucketsLoading } = useQuery({
    queryKey: ['/api/analysis/buckets'],
    queryFn: async () => {
      return await api.getDeviationBuckets('groupwise');
    },
  });

  const drillDownMutation = useMutation({
    mutationFn: ({ bucketRange, lowerBound, upperBound }: { bucketRange: string; lowerBound: number; upperBound?: number }) =>
      api.getDrillDownData(bucketRange, lowerBound, upperBound),
    onError: (error: any) => {
      toast({
        title: "Drill-down Failed",
        description: error.message || "Failed to get drill-down data",
        variant: "destructive",
      });
    },
  });

  const handleBucketSelect = (bucket: any) => {
    const [min, max] = bucket.range.includes('∞') 
      ? [parseFloat(bucket.range.split(' - ')[0]), undefined]
      : bucket.range.split(' - ').map((v: string) => parseFloat(v.replace('%', '')));

    setSelectedBucket(bucket.range);
    setSelectedBounds({ lower: min, upper: max });
    drillDownMutation.mutate({
      bucketRange: bucket.range,
      lowerBound: min,
      upperBound: max,
    });
  };

  const clearSelection = () => {
    setSelectedBucket(null);
    setSelectedBounds(null);
  };

  const exportFiltered = async () => {
    if (!drillDownMutation.data) return;
    
    try {
      const csvContent = convertToCSV(drillDownMutation.data.trades);
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `filtered-alerts-${selectedBucket?.replace(/[^a-zA-Z0-9]/g, '-')}.csv`;
      a.click();
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export filtered data",
        variant: "destructive",
      });
    }
  };

  const convertToCSV = (data: any[]) => {
    if (!data.length) return '';
    
    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => JSON.stringify(row[header] || '')).join(',')
      )
    ];
    
    return csvRows.join('\n');
  };

  const getExpandedBuckets = () => {
    if (!selectedBounds || selectedBounds.upper === undefined) return [];
    
    const step = 0.5;
    const buckets = [];
    let current = selectedBounds.lower;
    
    while (current < selectedBounds.upper) {
      const next = current + step;
      const range = `${current.toFixed(1)} - ${next.toFixed(1)}%`;
      // Mock data - in real implementation this would come from the server
      buckets.push({
        range,
        count: Math.floor(Math.random() * 50),
        percentage: (Math.random() * 100).toFixed(1) + '%'
      });
      current = next;
    }
    
    return buckets;
  };

  if (bucketsLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {[1, 2].map(i => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-center py-8">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Loading analysis...
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Groupwise Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Groupwise Deviation Buckets</CardTitle>
            <p className="text-sm text-neutral-500">Click on any bucket to drill down</p>
          </CardHeader>
          <CardContent>
            {buckets && buckets.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Deviation Bucket</TableHead>
                    <TableHead className="text-right">USD</TableHead>
                    <TableHead className="text-right">EUR</TableHead>
                    <TableHead className="text-right">GBP</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {buckets.map((bucket: any, index: number) => (
                    <TableRow 
                      key={index} 
                      className={`hover:bg-neutral-50 cursor-pointer ${
                        selectedBucket === bucket.range ? 'bg-blue-50 border-blue-200' : ''
                      } ${
                        bucket.range.includes('3.5') ? 'bg-red-50 border-red-200' : ''
                      }`}
                      onClick={() => handleBucketSelect(bucket)}
                    >
                      <TableCell className="font-medium">{bucket.range}</TableCell>
                      <TableCell className="text-right">{bucket.USD || 0}</TableCell>
                      <TableCell className="text-right">{bucket.EUR || 0}</TableCell>
                      <TableCell className="text-right">{bucket.GBP || 0}</TableCell>
                      <TableCell className="text-right font-medium">{bucket.total}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-chart-bar text-4xl text-neutral-300 mb-4"></i>
                <p className="text-neutral-500">No deviation data available</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Expanded Bucket Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Expanded Bucket Analysis</CardTitle>
            <p className="text-sm text-neutral-500">High deviation alerts breakdown</p>
          </CardHeader>
          <CardContent>
            {selectedBucket ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Range</TableHead>
                    <TableHead className="text-right">Count</TableHead>
                    <TableHead className="text-right">%</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getExpandedBuckets().map((bucket: any, index: number) => (
                    <TableRow key={index} className="hover:bg-neutral-50">
                      <TableCell className="font-medium">{bucket.range}</TableCell>
                      <TableCell className="text-right">{bucket.count}</TableCell>
                      <TableCell className="text-right">{bucket.percentage}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-mouse-pointer text-4xl text-neutral-300 mb-4"></i>
                <p className="text-neutral-500">Select a bucket to see expanded analysis</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Drill-down Results */}
      {selectedBucket && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>
                Selected Bucket: <span className="text-primary">{selectedBucket}</span>
              </CardTitle>
              <Button variant="outline" onClick={clearSelection}>
                <i className="fas fa-times mr-2"></i>
                Clear Selection
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {drillDownMutation.isPending ? (
              <div className="flex items-center justify-center py-8">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Loading drill-down data...
              </div>
            ) : drillDownMutation.data && drillDownMutation.data.trades.length > 0 ? (
              <>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Trade ID</TableHead>
                        <TableHead>CCY Pair</TableHead>
                        <TableHead>Legal Entity</TableHead>
                        <TableHead className="text-right">Deviation %</TableHead>
                        <TableHead>Alert Type</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {drillDownMutation.data.trades.slice(0, 50).map((trade: any, index: number) => (
                        <TableRow key={index} className="hover:bg-neutral-50">
                          <TableCell className="font-mono text-xs">{trade.tradeId}</TableCell>
                          <TableCell className="font-medium">{trade.ccyPair}</TableCell>
                          <TableCell>{trade.legalEntity}</TableCell>
                          <TableCell className="text-right font-medium text-yellow-600">
                            {trade.deviationPercent.toFixed(2)}%
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">Threshold</Badge>
                          </TableCell>
                          <TableCell>{new Date(trade.tradeDate).toLocaleDateString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <div className="flex justify-between items-center mt-6 pt-4 border-t">
                  <span className="text-sm text-neutral-500">
                    Showing {Math.min(50, drillDownMutation.data.count)} of {drillDownMutation.data.count} alerts in selected bucket
                  </span>
                  <Button onClick={exportFiltered}>
                    <i className="fas fa-download mr-2"></i>
                    Download Filtered Data
                  </Button>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-search text-4xl text-neutral-300 mb-4"></i>
                <p className="text-neutral-500">No alerts found in selected bucket</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
