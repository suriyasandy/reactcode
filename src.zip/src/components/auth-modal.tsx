import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface AuthModalProps {
  onSuccess: () => void;
  onClose: () => void;
}

export default function AuthModal({ onSuccess, onClose }: AuthModalProps) {
  const [authStatus, setAuthStatus] = useState({ uat: false, prod: false });
  const { toast } = useToast();

  const authenticateUat = useMutation({
    mutationFn: () => api.authenticateEnvironment('uat'),
    onSuccess: () => {
      setAuthStatus(prev => ({ ...prev, uat: true }));
      toast({
        title: "UAT Authentication Successful",
        description: "Connected to UAT environment",
      });
      checkBothAuthenticated();
    },
    onError: (error: any) => {
      toast({
        title: "UAT Authentication Failed",
        description: error.message || "Failed to authenticate with UAT",
        variant: "destructive",
      });
    },
  });

  const authenticateProd = useMutation({
    mutationFn: () => api.authenticateEnvironment('prod'),
    onSuccess: () => {
      setAuthStatus(prev => ({ ...prev, prod: true }));
      toast({
        title: "PROD Authentication Successful", 
        description: "Connected to PROD environment",
      });
      checkBothAuthenticated();
    },
    onError: (error: any) => {
      toast({
        title: "PROD Authentication Failed",
        description: error.message || "Failed to authenticate with PROD",
        variant: "destructive",
      });
    },
  });

  const checkBothAuthenticated = () => {
    setTimeout(() => {
      if (authStatus.uat && authStatus.prod) {
        onSuccess();
      }
    }, 100);
  };

  const canProceed = authStatus.uat && authStatus.prod;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <i className="fas fa-key text-primary"></i>
            Authentication Required
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* UAT Environment */}
          <div className="border rounded-lg p-4 bg-neutral-50">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-neutral-700">UAT Environment</h3>
              <Badge variant={authStatus.uat ? "default" : "secondary"}>
                {authStatus.uat ? "Connected" : "Pending"}
              </Badge>
            </div>
            <Button
              className="w-full"
              onClick={() => authenticateUat.mutate()}
              disabled={authenticateUat.isPending || authStatus.uat}
            >
              {authenticateUat.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Authenticating...
                </>
              ) : authStatus.uat ? (
                <>
                  <i className="fas fa-check mr-2"></i>
                  Connected
                </>
              ) : (
                <>
                  <i className="fas fa-sign-in-alt mr-2"></i>
                  Connect to UAT
                </>
              )}
            </Button>
          </div>

          {/* PROD Environment */}
          <div className="border rounded-lg p-4 bg-neutral-50">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-neutral-700">PROD Environment</h3>
              <Badge variant={authStatus.prod ? "default" : "secondary"}>
                {authStatus.prod ? "Connected" : "Pending"}
              </Badge>
            </div>
            <Button
              className="w-full"
              onClick={() => authenticateProd.mutate()}
              disabled={authenticateProd.isPending || authStatus.prod}
            >
              {authenticateProd.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Authenticating...
                </>
              ) : authStatus.prod ? (
                <>
                  <i className="fas fa-check mr-2"></i>
                  Connected
                </>
              ) : (
                <>
                  <i className="fas fa-sign-in-alt mr-2"></i>
                  Connect to PROD
                </>
              )}
            </Button>
          </div>

          {/* Proceed Button */}
          <div className="pt-4 border-t">
            <Button
              className="w-full bg-success hover:bg-green-700"
              disabled={!canProceed}
              onClick={onSuccess}
            >
              <i className="fas fa-arrow-right mr-2"></i>
              Proceed to Dashboard
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
