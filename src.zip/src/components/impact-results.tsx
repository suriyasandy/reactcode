import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/api";

interface ImpactResultsProps {
  onTabChange: (tab: string) => void;
}

export default function ImpactResults({ onTabChange }: ImpactResultsProps) {
  const { data: results, isLoading } = useQuery({
    queryKey: ['/api/analysis/results'],
  });

  const handleExport = async () => {
    try {
      const data = await api.exportData('results');
      // Create and download CSV
      const csvContent = convertToCSV(data.data);
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'impact-results.csv';
      a.click();
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const convertToCSV = (data: any[]) => {
    if (!data.length) return '';
    
    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => JSON.stringify(row[header] || '')).join(',')
      )
    ];
    
    return csvRows.join('\n');
  };

  const formatImpactPercent = (percent: number) => {
    const formatted = Math.abs(percent).toFixed(1);
    const isPositive = percent > 0;
    const color = isPositive ? 'text-red-600 bg-red-50' : 'text-green-600 bg-green-50';
    return (
      <Badge className={`${color} border-0`}>
        {isPositive ? '+' : '-'}{formatted}%
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <i className="fas fa-spinner fa-spin mr-2"></i>
            Loading impact analysis...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!results || results.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <i className="fas fa-chart-line text-4xl text-neutral-300 mb-4"></i>
            <h3 className="text-lg font-medium text-neutral-700 mb-2">No Analysis Results</h3>
            <p className="text-neutral-500 mb-4">Run threshold impact analysis to see results.</p>
            <Button onClick={() => onTabChange('threshold')}>
              <i className="fas fa-cog mr-2"></i>
              Configure Thresholds
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalReduction = results.reduce((acc: number, result: any) => acc + result.impactPercent, 0) / results.length;
  const totalAlertsSaved = results.reduce((acc: number, result: any) => acc + (result.origAlerts - result.adjAlerts), 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Threshold Impact Analysis Results</CardTitle>
          <Badge variant="secondary">Total Entities: {results.length}</Badge>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Legal Entity</TableHead>
                <TableHead>Source System</TableHead>
                <TableHead className="text-right">Total Volume</TableHead>
                <TableHead className="text-right">Orig Alerts</TableHead>
                <TableHead className="text-right">Proj Alerts</TableHead>
                <TableHead className="text-right">Adj Alerts</TableHead>
                <TableHead className="text-right">Impact %</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((result: any, index: number) => (
                <TableRow key={index} className="hover:bg-neutral-50">
                  <TableCell className="font-medium">{result.legalEntity}</TableCell>
                  <TableCell>{result.sourceSystem}</TableCell>
                  <TableCell className="text-right">{result.totalVolume.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{result.origAlerts.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{result.projAlerts.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-medium">{result.adjAlerts.toLocaleString()}</TableCell>
                  <TableCell className="text-right">
                    {formatImpactPercent(result.impactPercent)}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" title="View Details">
                        <i className="fas fa-eye"></i>
                      </Button>
                      <Button size="sm" variant="outline" title="Download Data">
                        <i className="fas fa-download"></i>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        <div className="flex justify-between items-center mt-6 pt-4 border-t">
          <div className="flex space-x-6 text-sm">
            <div className="flex items-center">
              <span className="text-neutral-500">Total Reduction:</span>
              <span className="ml-2">
                {formatImpactPercent(totalReduction)}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-neutral-500">Alerts Saved:</span>
              <span className="ml-2 font-medium text-green-600">
                {totalAlertsSaved.toLocaleString()}
              </span>
            </div>
          </div>
          <Button onClick={handleExport}>
            <i className="fas fa-download mr-2"></i>
            Export Results
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
